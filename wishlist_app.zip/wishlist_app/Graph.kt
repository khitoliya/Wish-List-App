package com.example.wishlist_app

import android.content.Context
import androidx.room.Room
import com.example.wishlist_app.data.WishDataBase
import com.example.wishlist_app.data.WishRepository

object Graph {
    lateinit var database:WishDataBase
    //lazy helps load wish repository in app when required and not at start to reduce app loading time
    val wishRepository by lazy {
        WishRepository(database.wishDao())
    }
    fun provide(context:Context){
        database= Room.databaseBuilder(context,WishDataBase::class.java,"WishList.db").build()
    }

}
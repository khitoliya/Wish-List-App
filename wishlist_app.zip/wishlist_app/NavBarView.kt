package com.example.wishlist_app
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Icon
import androidx.compose.material.IconButton
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.unit.dp

val customFontFamily = FontFamily(
    Font(R.font.gothic, FontWeight.Bold)
)
@Composable
fun NavBarView(
    title:String,
    onBackNavClick:(()->Unit) = {}
){

        // Back Button
        val navigationIcon:(@Composable ()->Unit)? = {
            if(!title.contains("WishList")){
                IconButton(onClick = { onBackNavClick() }) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        tint = colorResource(id = R.color.white),
                        contentDescription = null
                    )
                }
            }else{
                null
            }
        }

        //Top Bar
        TopAppBar(
            title = {
                Text(text = title, color = colorResource(id = R.color.white), fontFamily = customFontFamily, modifier = Modifier
                    .padding(start = 4.dp)
                    .heightIn(max = 24.dp)) },
            elevation = 3.dp,
            backgroundColor = colorResource(id =R.color.navBarColour ),
            navigationIcon = navigationIcon,
            modifier = Modifier.padding(bottom = 13.dp)
        )





}

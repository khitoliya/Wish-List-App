package com.example.wishlist_app

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.wishlist_app.data.Wish
import kotlinx.coroutines.flow.Flow
@Dao
abstract class WishDAO {
    //Insert in Data Base
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun addWish(wishEntity:Wish)

    //fetch data from database
    @Query("Select * from `wish-table`")
    abstract fun getAllWishes(): Flow<List<Wish>>  //Don't need to be suspend because already using flow

    //update Wish
    @Update
    abstract suspend fun updateWish(wishEntity:Wish)

    //Delete Wish
    @Delete
    abstract suspend fun deleteWish(wishEntity:Wish)

    @Query("Select * from `wish-table` where id=:Id")
    abstract fun getWishByID(Id:Long): Flow<Wish>
}
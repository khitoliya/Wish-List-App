package com.example.wishlist_app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wishlist_app.data.Wish
import com.example.wishlist_app.data.WishRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class WishViewModel(
    private val Respository:WishRepository = Graph.wishRepository
):ViewModel() {
    var titleState by mutableStateOf("")
    var descriptionState by mutableStateOf("")

    fun onWhishTitleChanged(newTitle:String){
        titleState=newTitle
    }
    fun onWhishDescriptionChanged(newDescription:String){
        descriptionState=newDescription

    }

    lateinit var getAllWishes: Flow<List<Wish>>
    init {
        viewModelScope.launch {
            getAllWishes=Respository.getAllWishes()
        }
    }

    fun AddWish(wish: Wish){
        viewModelScope.launch (Dispatchers.IO){
            Respository.AddWish(wish)
        }
    }
    fun UpdateWish(wish: Wish){
        viewModelScope.launch (Dispatchers.IO){
            Respository.UpdateWish(wish)
        }
    }
    fun getWishById(id:Long):Flow<Wish>{
        return Respository.getWishById(id)
    }
    fun DeleteWish(wish: Wish){
        viewModelScope.launch (Dispatchers.IO){
            Respository.DeleteWish(wish)
        }
    }
}

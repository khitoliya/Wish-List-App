package com.example.wishlist_app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

//creating table Wish-Table in dataBase
@Entity(tableName = "Wish-Table")
data class Wish(
    @PrimaryKey(autoGenerate = true)//declaring it as primary key and will increase automaticaly..if a entry is deleted(for ex, id=3) then that number is skipped and next item id will be 4 and not 3
    val id:Long=0L,
    @ColumnInfo(name = "Wish-Title")// creating columns of table
    val title:String="",
    @ColumnInfo(name = "Wish-Description")
    val description:String=""
)
object DummyList{
    val wishList= listOf(Wish(1,"Rolls Royce","Rolls-Royce is a British luxury car brand known for its elegance, craftsmanship, and exclusivity. Its iconic models, like the Phantom and Ghost"),
        Wish(2,"Lamborghini Urus","The Lamborghini Urus is a high-performance luxury SUV that combines Lamborghini's iconic supercar design with versatility. Powered by a twin-turbo V8 engine"))
}

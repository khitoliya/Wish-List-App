package com.example.wishlist_app.data

import androidx.room.Delete
import com.example.wishlist_app.WishDAO
import kotlinx.coroutines.flow.Flow


//This is our repository..that talks to DAO(cursor)or any other DataSource and is used by ViewModel

class WishRepository(private val wishDAO: WishDAO) {

    suspend fun AddWish(wish: Wish){
        wishDAO.addWish(wish)
    }
    fun getAllWishes(): Flow<List<Wish>> {
        return wishDAO.getAllWishes()
    }
    fun getWishById(ID:Long):Flow<Wish>{
        return wishDAO.getWishByID(ID)
    }
    suspend fun UpdateWish(wish: Wish){
        wishDAO.updateWish(wish)
    }
    suspend fun DeleteWish(wish: Wish){
        wishDAO.deleteWish(wish)
    }
}
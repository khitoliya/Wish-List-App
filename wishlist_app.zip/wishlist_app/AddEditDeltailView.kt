package com.example.wishlist_app

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Scaffold
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material.TextFieldDefaults
import androidx.compose.material.rememberScaffoldState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.wishlist_app.data.Wish
import kotlinx.coroutines.launch

@Composable
fun AddEditDetailView(
    viewModel: WishViewModel,
    navController: NavController,
    id:Long
){
    // It is like a Toast message to display confirmation when item is added or updated
    val snackMessage = remember{ mutableStateOf("")}
    val scope= rememberCoroutineScope()
    val scaffoldState= rememberScaffoldState()
    if(id!=0L){val wish = viewModel.getWishById(id).collectAsState(initial =Wish(0L,"",""));viewModel.titleState=wish.value.title;viewModel.descriptionState=wish.value.description}else{viewModel.titleState = "";viewModel.descriptionState = ""}
    Scaffold(
        topBar = { NavBarView(title = if(id==0L) stringResource(id = R.string.add_wish)else stringResource(id = R.string.update_wish )
                             , onBackNavClick = {navController.navigateUp()})
        },
        scaffoldState= scaffoldState, backgroundColor = colorResource(id = R.color.navBarColour)

    ) {
        Column(modifier=Modifier.padding(it), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Spacer(modifier = Modifier.height(10.dp))
            WishTextField(label = "Title", value = viewModel.titleState, onValueChanged = {viewModel.onWhishTitleChanged(it)})
            Spacer(modifier = Modifier.height(10.dp))
            WishTextField(label = "Description", value = viewModel.descriptionState, onValueChanged = {viewModel.onWhishDescriptionChanged(it)})
            Spacer(modifier = Modifier.height(18.dp))


            //Button to update or add item
            Button(onClick = { /*add or update into data base*/
                                if(viewModel.titleState.isNotEmpty()&&viewModel.descriptionState.isNotEmpty()){
                                    if(id!=0L){
                                        //TODO Update wish
                                        //already loaded wish above from data base
                                        viewModel.UpdateWish(Wish(id,viewModel.titleState.trim(),viewModel.descriptionState.trim()))
                                        snackMessage.value="Wish Updated Sucessfully"

                                    }
                                    else{
                                        //TODO new wish
                                        viewModel.AddWish(Wish(title= viewModel.titleState.trim(), description = viewModel.descriptionState.trim()))
                                        snackMessage.value="Wish has been Created"
                                    }
                                }
                                else{
                                    snackMessage.value="Enter fields to create Wish"
                                }
                //Go back after adding or updating
                if(snackMessage.value!="Enter fields to create Wish"){
                    scope.launch{
                        //scaffoldState.snackbarHostState.showSnackbar(snackMessage.value)
                        navController.navigateUp()
                        viewModel.titleState=""
                        viewModel.descriptionState=""
                    }
                }



            }, colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White)) {
                Text(
                    text = if (id == 0L) stringResource(id = R.string.add_wish) else stringResource(id = R.string.update_wish),
                    style = TextStyle(fontSize = 17.sp), modifier = Modifier.padding(start = 20.dp,end=20.dp,top=8.dp, bottom = 8.dp)
                )
            }
        }
    }
}


@Composable
fun WishTextField(
    label:String,
    value:String,
    onValueChanged:(String)->Unit
){
    OutlinedTextField(
        value = value,
        onValueChange = onValueChanged,
        label={ Text(text = label, color = colorResource(id = R.color.white))},
        modifier=Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
        colors = TextFieldDefaults.outlinedTextFieldColors(
            textColor = Color.White,
            focusedBorderColor = colorResource(id = R.color.Element_Colour),
            unfocusedBorderColor = colorResource(id = R.color.Element_Colour),
            cursorColor =colorResource(id = R.color.white) ,
            focusedLabelColor = colorResource(id = R.color.white),
            unfocusedLabelColor = colorResource(id = R.color.white),
            backgroundColor = colorResource(id = R.color.Element_Colour)
        ),
        shape = RoundedCornerShape(15.dp)
        )
}
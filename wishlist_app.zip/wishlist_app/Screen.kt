package com.example.wishlist_app

sealed class Screen(val route:String) {
    data object HomeScreen: Screen("homeView")
    data object AddScreen: Screen("AddView")
}